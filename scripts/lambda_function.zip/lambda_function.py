import boto3

def lambda_handler(event, context):
    glue_client = boto3.client('glue')
    trigger_name = "tf-glue-project-source-crawler-trigger"

    try:
        response = glue_client.start_trigger(Name=trigger_name)
        print(f"Started trigger: {trigger_name}")
        return response
    except glue_client.exceptions.ConcurrentRunsExceededException:
        print(f"Trigger {trigger_name} is already running.")
        return {"status": "Trigger already running"}
    except Exception as e:
        print(f"Error starting trigger: {str(e)}")
        raise
